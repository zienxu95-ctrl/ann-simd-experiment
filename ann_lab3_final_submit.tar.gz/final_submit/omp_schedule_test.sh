#!/bin/bash

mkdir -p logs_schedule
cp main_omp.cc main_omp_schedule_base.cc

declare -A SCHEDULES
SCHEDULES["static"]="schedule(static)"
SCHEDULES["dynamic1"]="schedule(dynamic,1)"
SCHEDULES["dynamic10"]="schedule(dynamic,10)"
SCHEDULES["guided"]="schedule(guided)"

for name in static dynamic1 dynamic10 guided
do
    echo "===== Building OpenMP schedule: $name ====="

    cp main_omp_schedule_base.cc main_omp_${name}.cc

    sed -i "s/#pragma omp parallel for schedule([^)]*)/#pragma omp parallel for ${SCHEDULES[$name]}/" main_omp_${name}.cc

    g++ -O3 -std=c++17 -march=native -fopenmp main_omp_${name}.cc -o ann_omp_${name}

    if [ $? -ne 0 ]; then
        echo "compile failed: $name"
        exit 1
    fi

    for t in 4 8
    do
        for r in 1 2 3
        do
            echo "schedule=$name threads=$t repeat=$r"
            OMP_NUM_THREADS=$t ./ann_omp_${name} > logs_schedule/${name}_t${t}_r${r}.log
            grep "average recall" logs_schedule/${name}_t${t}_r${r}.log
            grep "throughput average latency" logs_schedule/${name}_t${t}_r${r}.log
            echo
        done
    done
done

echo "All schedule tests finished."
