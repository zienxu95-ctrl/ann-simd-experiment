#!/bin/bash
# 批量测试不同 P 值，自动编译并生成日志

# P 值列表
P_VALUES=(10 20 50 100)

# 输出目录
LOG_DIR="logs"
mkdir -p $LOG_DIR

# 备份 main.cc
cp main.cc main.cc.bak

for P in "${P_VALUES[@]}"; do
    echo "===== Testing P=$P ====="
    
    # 替换 main.cc 中 P 值
    sed -i "s/size_t P = [0-9]\+/size_t P = $P/" main.cc
    
    # 编译
    g++ -O3 -std=c++17 -march=native -fopenmp main.cc -o ann_run
    
    if [ $? -ne 0 ]; then
        echo "Compilation failed for P=$P"
        exit 1
    fi
    
    # 运行并保存日志
    ./ann_run > $LOG_DIR/run_P${P}.log
    echo "P=$P done. Last 5 lines:"
    tail -n 5 $LOG_DIR/run_P${P}.log
    echo
done

# 恢复 main.cc
mv main.cc.bak main.cc

echo "All tests finished. Logs are in $LOG_DIR/"
